from django.contrib import admin
from  import_export.admin import ImportExportActionModelAdmin
from .models import client_Master,Protocol_Master,Bin_Master,Temperature_Master,Supplier_Master,Site_Master,Upload_Randomization
# Register your models here.
class UploadAdmin(ImportExportActionModelAdmin):
    list_display=['Randomization_Number','Protocol_Master']
    fields = ['Protocol_Master','Randomization_Number','Treatment_code','Treatment_Description'] 


admin.site.register(client_Master)
admin.site.register(Protocol_Master)
admin.site.register(Bin_Master)
admin.site.register(Temperature_Master)
admin.site.register(Site_Master)
admin.site.register(Supplier_Master)
admin.site.register(Upload_Randomization,UploadAdmin)    