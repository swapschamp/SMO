from django.db import models
from  django.contrib.auth.models import User
# Create your models here.

class client_Master(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    company_Name = models.CharField(max_length=200)
    Address = models.TextField()
    Email = models.EmailField()
    contact_no = models.CharField(max_length=200)
    created_on = models.DateTimeField(auto_now_add=True)
    #created_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='create')
    #updated_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='update')
    
    def __str__(self):
        return self.company_Name

    class Meta:
        verbose_name = 'Client'
        verbose_name_plural = 'Client'    


class Protocol_Master(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    Protocol_Number = models.CharField(max_length=200)
    client_Master=models.ForeignKey(client_Master,on_delete=models.CASCADE)
    created_on = models.DateTimeField(auto_now_add=True)
    #created_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='create')
    #updated_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='update')


    def __str__(self):
        return self.Protocol_Number

class Upload_Randomization(models.Model):
    Protocol_Master = models.ForeignKey(Protocol_Master,on_delete=models.CASCADE)
    Randomization_Number = models.CharField('Randomization Number',max_length=500)
    Treatment_code = models.CharField('Treament Code',max_length=200,null=True)
    Treatment_Description = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)

class Site_Master(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    Site_Number = models.CharField(max_length=120)
    PIName = models.CharField('PI Name',max_length=220)
    Person_Name = models.CharField('Person Name',max_length=200)
    Site_Address = models.TextField('Site Address',max_length=500)
    Contact_No = models.CharField('Contact Number',max_length=500)
    created_on = models.DateTimeField(auto_now_add=True)
   #created_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='create')
    #updated_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='update')



    def __str__(self):
        return self.Site_Number


class Bin_Master(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    Bin_Number = models.CharField(max_length=120)
    created_on = models.DateTimeField(auto_now_add=True)
   # created_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='create')
    #updated_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='update')



    def __str__(self):
        return self.Bin_Number


class Temperature_Master(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    Temp = models.CharField('Temperature Master',max_length=120)
    created_on = models.DateTimeField(auto_now_add=True)
    #created_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='create')
    #updated_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='update')


    def __str__(self):
        return self.Temp

'''
class Order(models.Model):
    STATUS_CHOICE = (
        ('pending', 'Pending'),
        ('decline', 'Decline'),
        ('approved', 'Approved'),
        ('processing', 'Processing'),
        ('complete', 'Complete'),
        ('bulk', 'Bulk'),
    )
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    design = models.CharField(max_length=50)
    color = models.CharField(max_length=50)
    buyer = models.ForeignKey(Buyer, on_delete=models.CASCADE, null=True)
    season = models.ForeignKey(Season, on_delete=models.CASCADE, null=True)
    drop = models.ForeignKey(Drop, on_delete=models.CASCADE, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICE)
    created_date = models.DateField(auto_now_add=True)


    def __str__(self):
        return self.product.name
'''

class Courier(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    courier_name = models.CharField(max_length=120)
    created_on = models.DateTimeField(auto_now_add=True)
    #created_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='create')
    #updated_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='update')

    def __str__(self):
        return self.courier_name

class Supplier_Master(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    supplier_name = models.CharField('Supplier Name',max_length=120)
    supplier_Number = models.CharField('Supplier Name',max_length=120)
    Email = models.CharField('Email',max_length=100)
    PO_Number = models.CharField('PO Number',max_length=120)
    Supplier_Address = models.TextField()
    City = models.CharField(max_length=100)
    State = models.CharField('Sate/Province',max_length=100)
    Zip_Code = models.CharField('Zip Code',max_length=20)
    Bank = models.TextField('Bank Name/Branch/Address')
    Currency = models.CharField('Currency',max_length=100)
    created_on = models.DateTimeField(auto_now_add=True)
    #created_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='create')
    #updated_by = models.ForeignKey(User, on_delete=models.DO_NOTHING, blank=True, null=True, related_name='update')

    def __str__(self):
        return self.supplier_name,self.supplier_Number      